package com.example.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment1Day15ECommercePaymentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment1Day15ECommercePaymentServiceApplication.class, args);
	}

}
