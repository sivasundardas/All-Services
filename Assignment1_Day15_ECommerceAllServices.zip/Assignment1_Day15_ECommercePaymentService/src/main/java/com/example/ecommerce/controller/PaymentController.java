package com.example.ecommerce.controller;

import org.springframework.web.bind.annotation.*;

import com.example.ecommerce.entity.Payment;

@RestController
@RequestMapping("/payments")
public class PaymentController {

    @PostMapping
    public Payment processPayment(@RequestBody Payment payment) {
        // Simulate payment success for simplicity
        payment.setStatus("SUCCESS");
        return payment;
    }
}