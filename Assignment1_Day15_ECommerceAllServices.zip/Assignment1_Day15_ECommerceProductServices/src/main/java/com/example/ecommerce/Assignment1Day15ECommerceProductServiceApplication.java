package com.example.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment1Day15ECommerceProductServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment1Day15ECommerceProductServiceApplication.class, args);
	}

}
