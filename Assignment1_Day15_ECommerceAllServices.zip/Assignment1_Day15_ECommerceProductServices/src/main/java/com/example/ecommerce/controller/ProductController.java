package com.example.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.ecommerce.entity.Product;
import com.example.ecommerce.repository.ProductRepository;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductRepository repo;

    @PostMapping
    public Product addProduct(@RequestBody Product product) {
        return repo.save(product);
    }

    @GetMapping("/{id}")
    public Product getProduct(@PathVariable String id) {
        return repo.findById(id).orElse(null);
    }

    @GetMapping
    public List<Product> getAllProducts() {
        return repo.findAll();
    }

    @PutMapping("/{id}/reduceStock")
    public Product reduceStock(@PathVariable String id, @RequestParam int qty) {
        Product p = repo.findById(id).orElse(null);
        if (p != null && p.getStock() >= qty) {
            p.setStock(p.getStock() - qty);
            repo.save(p);
        }
        return p;
    }

    @PutMapping("/{id}")
    public Product updateProduct(@PathVariable String id, @RequestBody Product product) {
        return repo.save(product);
    }
}