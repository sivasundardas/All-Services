package com.example.ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment1Day15ECommerceOrderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
