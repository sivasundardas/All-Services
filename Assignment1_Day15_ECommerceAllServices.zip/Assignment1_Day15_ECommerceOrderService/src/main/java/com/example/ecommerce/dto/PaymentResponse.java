package com.example.ecommerce.dto;

public class PaymentResponse {

	private String status;
    // getters and setters

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
